module.exports = {
    url: 'mongodb://admin:adminpass@23.23.153.188:27017/tool,'+
            'mongodb://admin:adminpass@107.22.174.155:27017'
}